﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class UserSession
    {
        public Userenum Un  = Userenum.None;
        public Dictionary<string, string> Endb = new Dictionary<string, string>();
    }
}
